module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: '111111',
        port: '3306',
        database: 'login'
    }
}
