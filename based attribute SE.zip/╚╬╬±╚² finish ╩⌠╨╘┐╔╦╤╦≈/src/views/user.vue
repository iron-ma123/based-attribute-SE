<template>
 <el-container>
  <el-aside width="200px" class="border" style="height: 965px;">
    
    <el-menu
        default-active="2"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        background-color="rgba(48,52,71,0)"
        text-color="#fff"
        active-text-color="#fff"     
       >

        <el-submenu index="1" > 
          <template slot="title">
            <i class="el-icon-search"></i>
            <span >查询数据</span>
            <!-- <div class="menu-divider"></div> -->
          </template> 
          <div class="menu-divider"></div>
          <el-menu-item index="1-1"  @click="showContent('明文查询')" >明文查询</el-menu-item>
          <div class="menu-divider"></div> 
        <el-submenu index="1-2">
          <div class="menu-divider"></div>
          <template slot="title" ><span >密文查询</span></template>
          <div class="menu-divider"></div>
          <el-menu-item index="1-2-1" @click="showContent('密文')" >密文</el-menu-item>
          <div class="menu-divider"></div>
          <el-menu-item index="1-2-2" @click="showContent('部分解密')" >部分解密</el-menu-item>
          <!-- <div class="menu-divider"></div> -->
        </el-submenu>   
        </el-submenu>
        <div class="menu-divider"></div>

        <el-menu-item index="2" @click="showContent('上传数据')">
          <i class="el-icon-upload"></i>
          <span slot="title" >上传数据</span>
        </el-menu-item> 
        <div class="menu-divider"></div>       
        <el-menu-item index="3" @click="showContent('用户注册')">
          <i class="el-icon-s-custom"></i>
          <span slot="title" >用户注册</span>
        </el-menu-item>       
      </el-menu>
  </el-aside>
  <el-container>
<!-- header -->
    <el-header height="600px" > 
    
    <div class="header-content">
 
    <div class="right-content" style="height: 10px; margin-top: -10px;" >
        <p style="color: rgb(104, 110, 116); font-weight: bold;">属性: {{ $route.query.username }}</p>
      </div>

<el-row>
  <el-col :span="24"><div class="grid-content bg-purple-light2">   
      <div class="left-content">
       <h2 style="color: rgb(104, 110, 116); font-weight: bold;" >{{ currentTitle }}</h2> 
       <textarea id="receiveTextarea" v-model="receivedData" readonly></textarea>
       <el-collapse v-model="activeNames" @change="handleChange">
       <el-collapse-item title="历史记录" name="1">
       <ul>
        <li v-for="message in receivedMessages" :key="message.id">{{ message.text }}</li>
        </ul>
      </el-collapse-item> 
    </el-collapse> 
      </div>
    </div></el-col>
</el-row>


  </div>
</el-header>

    <el-main >
      <div v-if="currentContent === '明文查询'">
        <div class="input-container">
    <el-input class="input" size="medium" placeholder="请输入查询内容" suffix-icon="el-icon-search" v-model="inputKeyword"></el-input>
    <div class="button-container" >
      <el-button type="primary" round icon="el-icon-search" @click="sendData">明文搜索</el-button>
    </div>
    <!-- <el-input class="input" size="medium" placeholder="请输入内容" suffix-icon="el-icon-date" v-model="input2"></el-input> -->
  </div>
    
      </div>
      <div v-else-if="currentContent === '密文'">
        <div class="input-container">
    <el-input class="input" size="medium" placeholder="请输入查询内容" suffix-icon="el-icon-search" v-model="inputKeyword"></el-input>
    <div class="button-container" >
      <el-button type="primary" round icon="el-icon-search" @click="sendqueryCiphertext">密文搜索</el-button>
    </div>
    <!-- <el-input class="input" size="medium" placeholder="请输入内容" suffix-icon="el-icon-date" v-model="input2"></el-input> -->
  </div>
      </div>
      
      <div v-else-if="currentContent === '部分解密'">
        <div class="input-container">
    <el-input class="input" size="medium" placeholder="请输入查询内容" suffix-icon="el-icon-search" v-model="inputKeyword"></el-input>
    <div class="button-container" >
      <el-button type="primary" round icon="el-icon-search" @click="sendpartialDecryptCiphertext">部分解密搜索</el-button>
    </div>
    <!-- <el-input class="input" size="medium" placeholder="请输入内容" suffix-icon="el-icon-date" v-model="input2"></el-input> -->
  </div>
      </div>
      <div v-else-if="currentContent === '上传数据'"> 
        <div class="input-container">
    <el-input class="input" size="medium" placeholder="请输入上传的数据" suffix-icon="el-icon-upload" v-model="inputPlaintext"></el-input>
    <el-input class="input" size="medium" placeholder="关键词" suffix-icon="el-icon-tickets" v-model="inputKeyword"></el-input>
    <el-input class="input" size="medium" placeholder="访问策略" suffix-icon="el-icon-view" v-model="inputAccesss"></el-input>
    <div class="button-container" >
      <el-button type="primary" round icon="el-icon-upload" @click="senduploadCiphertext">上传数据</el-button>
    </div>
    <!-- <el-input class="input" size="medium" placeholder="请输入内容" suffix-icon="el-icon-date" v-model="input2"></el-input> -->
  </div>
      </div>

      <div v-else-if="currentContent === '用户注册'"> 
        
    <div class="button-container" >
      <el-button type="primary" round icon="el-icon-upload" @click="sendDataConsumer">初始化</el-button>
    </div>
      </div>
    </el-main>

  </el-container>
</el-container>
</template>

  <script>
    export default {
      data() {
      return {
      currentContent: '',
      inputKeyword: '',      
      inputPlaintext: '',
      inputAccesss: '',
      receivedData: '', // 用于存储接收的最新信息
      receivedMessages: [], // 用于存储接收的所有信息
      currentTitle: '请选择查询/上传',
      activeNames: ['1'],
      };
     },

      methods: {
        handleOpen(key, keyPath) {
          console.log(key, keyPath);
        },
        handleClose(key, keyPath) {
          console.log(key, keyPath);
        },
        showContent(content) {
         this.currentContent = content;
        },  
        handleChange(val) {
         console.log(val);
        },   
        sendData() {
        const data = { 
          query: 'fullDecryptCiphertext', 
          attributes: this.$route.query.username,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,          
          method: 'send',
        };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);}
      },
      sendqueryCiphertext() {  //数据使用者请求密文
      const data = {
          query: 'queryCiphertext',//发这个
          attributes: this.$route.query.username,          
          keywordsSet: this.inputKeyword,// 只发关键词          
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
    sendpartialDecryptCiphertext() { //数据使用者部分解密
      const data = {
          query: 'partialDecryptCiphertext',
          attributes: this.$route.query.username,      
          keywordsSet: this.inputKeyword,          
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
    senduploadCiphertext() {
      const data = {
          query: 'uploadCiphertext',
          attributes: this.$route.query.username,
          plainMessage: this.inputPlaintext,//明文传
          keywordsSet: this.inputKeyword,//关键词传
          accessExpression: this.inputAccesss,//访问策略传
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
  
    showContent(content) {
    this.currentContent = content;
    if (content === '上传数据') {
      this.currentTitle = '上传的数据：';
    } else {
      this.currentTitle = '接收的信息:';
    }
  },
  sendDataConsumer() {    //初始化data consumer
      const data = {
          query: 'init_DataConsumer',
          attributes: this.$route.query.username,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
    //继续放按钮
      },
      created() {
    // 创建 WebSocket 连接
    this.socket = new WebSocket('ws://localhost:8824');

    // 监听 WebSocket 连接状态
    this.socket.addEventListener('open', () => {
      console.log('WebSocket connection is open.');
    });

    // 监听 WebSocket 错误
    this.socket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
    });

    // 监听 WebSocket 消息事件
    this.socket.addEventListener('message', (event) => {
      const receivedText = event.data;

      this.receivedData = receivedText; // 将接收的最新信息显示在接收窗口
      this.receivedMessages.push({ id: Date.now(), text: receivedText }); // 将接收的信息添加到数组中
    });
  },
     }
  </script>
<style>
.el-header, .el-footer {
  background:  rgba(43, 43, 43, 0);
  
  text-align: left;
  line-height: 150px;
}

.el-aside {
  background:  rgba(28, 32, 53, 0.904);
 
  text-align: left;
  line-height: 3000px; 
}

.el-main {
  background:  rgb(255, 255, 255);
   text-align: left;
  line-height: 10px;
}

#receiveTextarea {
  width: 100%; /* 设置宽度为100%，以充满其容器 */
  height: 200px; /* 设置高度为400px，根据需求进行调整 */
  padding: 5px; /* 可选的内边距，根据需求进行调整 */
}

.input-container {
  display: flex; /* 使用 Flexbox 布局 */
  /* justify-content: space-between; 水平分散对齐输入框 */
}

.input {
  width: 25% !important;
}

.button-container {
  margin-left: 10px;
 }

 .border {
  border: 1px solid #ccc; /* 添加组件的边界线 */
}


.right-content {
  text-align: right;

  font-size: 16px; /* 设置字体大小 */
  color: #ffffff; /* 设置字体颜色 */
}

.left-content {  
  margin-top: 0px; /* 调整属性信息距离右边的距离 */
  font-size: 20px; /* 设置字体大小 */
  color: #333; /* 设置字体颜色 */
}

  .bg-purple-light {
    background: #ffffff;
  }
  .bg-purple-light2 {
    background: rgba(192, 232, 246, 0.103);
  }
  
  .grid-content {
    border-radius: 100px;
    min-height:0px;
  }  
  .menu-divider::after {
    content: '';
    display: block;
    height: 0.1px;
    background-color: #bcbbbb; /* 设置分隔线颜色 */
    
  }
</style>