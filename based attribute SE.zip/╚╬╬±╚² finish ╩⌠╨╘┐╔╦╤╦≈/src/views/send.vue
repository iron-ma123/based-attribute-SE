<template>
<div>  
  <div>    
    <div>
      <label for="attributeInput">属性：</label>
      <input type="text" id="attributeInput" v-model="inputAttribute" />
    </div>
    <div>
      <label for="plaintextInput">明文：</label>
      <input type="text" id="plaintextInput" v-model="inputPlaintext" />
    </div>
    <div>
      <label for="keywordInput">明文关键词：</label>
      <input type="text" id="keywordInput" v-model="inputKeyword" />
    </div>
    <div>
      <label for="accessInput">访问策略：</label>
      <input type="text" id="accessInput" v-model="inputAccesss" />
    </div>
    <button @click="sendTA">初始化TA</button>
    <button @click="sendDataOwner">初始化DataOwner</button>
    <button @click="sendDataConsumer">初始化DataConsumer</button>
    <button @click="sendCloudServer">初始化CloudServer</button>
    <button @click="sendEdgeNode">初始化EdgeNode</button>
    <button @click="senduploadCiphertext">数据拥有者存储消息</button>
    <button @click="sendqueryCiphertext">数据使用者请求密文</button>
    <button @click="sendpartialDecryptCiphertext">数据使用者部分解密</button>
    <button @click="sendfullDecryptCiphertext">数据使用者完全解密</button>
    <button @click="sendData">发送</button>
  </div>

  <div>
    <h2>接收的信息:</h2>
    <textarea id="receiveTextarea" v-model="receivedData" readonly style="width: 100%; height: 3000px;"></textarea>
    <ul>
      <li v-for="message in receivedMessages" :key="message.id">{{ message.text }}</li>
    </ul>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      
      inputAttribute: '',
      inputPlaintext: '',
      inputKeyword: '',
      inputAccesss: '',
      socket: null,
      receivedData: '', // 用于存储接收的最新信息
      receivedMessages: [], // 用于存储接收的所有信息
    };
  },

  methods: {
    sendTA() {
      const data = {     
          query: 'init_TA',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',       
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendDataOwner() {
      const data = { 
          query: 'init_DataOwner',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendDataConsumer() {    //初始化data consumer
      const data = {
          query: 'init_DataConsumer',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendCloudServer() {
      const data = {
          query: 'init_CloudServer',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendEdgeNode() {
      const data = {
          query: 'init_EdgeNode',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    senduploadCiphertext() {
      const data = {
          query: 'uploadCiphertext',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,//明文传
          keywordsSet: this.inputKeyword,//关键词传
          accessExpression: this.inputAccesss,//访问策略传
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendqueryCiphertext() {  //数据使用者请求密文
      const data = {
          query: 'queryCiphertext',//发这个
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,// 只发关键词
          accessExpression: this.inputAccesss,
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendpartialDecryptCiphertext() { //数据使用者部分解密
      const data = {
          query: 'partialDecryptCiphertext',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendfullDecryptCiphertext() { //
      const data = {
          query: 'fullDecryptCiphertext',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
    
    sendData() {
      const data = {          
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',

      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
  },
  created() {
    // 创建 WebSocket 连接
    this.socket = new WebSocket('ws://localhost:8824');

    // 监听 WebSocket 连接状态
    this.socket.addEventListener('open', () => {
      console.log('WebSocket connection is open.');
    });

    // 监听 WebSocket 错误
    this.socket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
    });

    // 监听 WebSocket 消息事件
    this.socket.addEventListener('message', (event) => {
      const receivedText = event.data;

      this.receivedData = receivedText; // 将接收的最新信息显示在接收窗口
      this.receivedMessages.push({ id: Date.now(), text: receivedText }); // 将接收的信息添加到数组中
    });
  },
};
</script>

<style scoped>
/* 添加组件特有的 CSS 样式，scoped 属性确保样式仅在当前组件内有效 */
div {
  margin: 10px;
  padding: 10px;
}

label {
  font-weight: bold;
}

input[type="text"] {
  width: 100%;
  padding: 5px;
  margin-top: 5px;
}

button {
  background-color: #007BFF;
  color: white;
  padding: 10px 20px;
  border: none;
  cursor: pointer;
  margin-top: 10px;
}

button:hover {
  background-color: #0056b3;
}

textarea {
  width: 100%;
  height: 200px; /* 设置文本框的高度，根据需要调整 */
  padding: 5px;
  margin-top: 5px;
}
</style>
