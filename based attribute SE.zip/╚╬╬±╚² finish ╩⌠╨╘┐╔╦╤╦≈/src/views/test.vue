<template>
    <div> 
    <el-input class="input" size="medium" placeholder="属性" suffix-icon="el-icon-upload" v-model="inputAttribute"></el-input> 
    <el-button type="primary" round icon="el-icon-upload"  @click="sendTA">初始化TA</el-button>     
    <el-button type="primary" round icon="el-icon-upload"  @click="sendDataOwner">初始化DataOwner</el-button>
    <el-button type="primary" round icon="el-icon-upload"  @click="sendDataConsumer">初始化DataConsumer</el-button>     
    <el-button type="primary" round icon="el-icon-upload"  @click="sendCloudServer">初始化CloudServer</el-button>
    <el-button type="primary" round icon="el-icon-upload"  @click="sendEdgeNode">初始化EdgeNode</el-button>
    <div class="left-content" style="position: relative; top: 50px; left: 20px; width: 500px; height: 100px; ">
       <h2 style="color: rgb(104, 110, 116); font-weight: bold;" >状态</h2> 
       <textarea id="receiveTextarea" v-model="receivedData" readonly ></textarea>
    </div>   
    <div id="messageContainer">
      <table v-if="tableData.length">
        <thead>
          <tr>
            <th v-for="key in Object.keys(tableData[0])">{{ key }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in tableData">
            <td v-for="value in Object.values(item)">{{ value }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    
    </div>
</template>

<script>

export default{
    data() {
     return {
      
      inputAttribute: '',      
      socket: null,
      receivedData: '', // 用于存储接收的最新信息
      receivedMessages: [], // 用于存储接收的所有信息
      ws: null,
      tableData: [], // 存储表格数据
      };
    },
    
methods:{
    sendTA() {
      const data = {     
          query: 'init_TA',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',       
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
    sendDataOwner() {
      const data = { 
          query: 'init_DataOwner',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendDataConsumer() {    //初始化data consumer
      const data = {
          query: 'init_DataConsumer',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendCloudServer() {
      const data = {
          query: 'init_CloudServer',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
      };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },

    sendEdgeNode() {
      const data = {
          query: 'init_EdgeNode',
          attributes: this.inputAttribute,
          plainMessage: this.inputPlaintext,
          keywordsSet: this.inputKeyword,
          accessExpression: this.inputAccesss,
          method: 'send',
    };

      // 将数据转为 JSON 字符串
      const jsonData = JSON.stringify(data);

      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(jsonData);
      }
    },
    //继续放按钮
},
created() {
    // 创建 WebSocket 连接
    this.socket = new WebSocket('ws://localhost:8824');

    // 监听 WebSocket 连接状态
    this.socket.addEventListener('open', () => {
      console.log('WebSocket connection is open.');
    });

    // 监听 WebSocket 错误
    this.socket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
    });

    // 监听 WebSocket 消息事件
    this.socket.addEventListener('message', (event) => {
      const receivedText = event.data;

      this.receivedData = receivedText; // 将接收的最新信息显示在接收窗口
      this.receivedMessages.push({ id: Date.now(), text: receivedText }); // 将接收的信息添加到数组中
    });
  },
  created() {
    // 创建WebSocket连接
    this.ws = new WebSocket("ws://localhost:8823");
    // 监听WebSocket消息事件
    this.ws.addEventListener("message", (event) => {
      const recvText = event.data;
      const jsonArray = JSON.parse(recvText);
      jsonArray.forEach((element) => {
        this.tableData.push(element);
      });
    });
  },
}
</script>

<style>
/* 添加消息容器的样式 原css */
#messageContainer {
  height: 400px;
  overflow-y: auto;
  /* 可以设置其他样式，如背景颜色、边框等，以符合您的设计需求 */
}

/* 表格样式 */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

th, td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: left;
}

th {
  background-color: #f2f2f2;
}

/* 行的交替背景颜色 */
tr:nth-child(even) {
  background-color: #f2f2f2;
}

tr:nth-child(odd) {
  background-color: #fff;
}

/* 悬停时高亮 */
tr:hover {
  background-color: #ddd;
}
</style>
