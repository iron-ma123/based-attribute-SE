<template>
  <div id="app">
	<div class="t1">
	<router-link :to="{name:'test'}">管理员模式</router-link> 
    </div>
	<!-- <router-link :to="{name:'send'}">send</router-link>  -->
	<!-- <router-link :to="{name:'user'}">user</router-link>  -->
    <router-view></router-view>
  </div>
</template>

<style scoped="scoped">
	#app{
		width: 100vw;
		height: 100vh;
		background-color: #f5f5f5;
	}
	.t1{
		color: #c31010;
	}
</style>
