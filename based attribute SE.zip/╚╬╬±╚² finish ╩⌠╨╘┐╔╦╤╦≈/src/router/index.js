import Vue from 'vue'
import VueRouter from 'vue-router'
import loginRegister from '../views/loginRegister.vue'
import test from '../views/test.vue'
// import send from '../views/send.vue'
import user from '../views/user.vue'
Vue.use(VueRouter)

const routes = [
  {
	  path:'/',
	  name:'login',
	  component: loginRegister
  },
  {
	  path:'/user',
	  name:'user',
	  component: user,
   
  },
  {
	  path:'/test',
	  name:'test',
	  component: test,
   
  },
  {
	  path:'/user',
	  name:'user',
	  component: user,
   
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
